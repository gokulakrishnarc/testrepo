import { LoginPage } from './page-objects/login.po';
import { browser, by, element, ElementFinder, promise, protractor } from 'protractor';
import { NoteViewPage } from './page-objects/noteview.po';

describe('Category page', () => {
  let page: LoginPage;
  let note: NoteViewPage;
  beforeEach(() => {
    page = new LoginPage();
    note = new NoteViewPage();
  });

  /*it('Login --> Display Notes View', () => {
    page.navigateToLogin();
    let newNoteValues = page.addLoginValues();
    expect(page.getLoginInputBoxesDefaultValues()).toEqual(newNoteValues, 'Should be able to set values for username and password');
    page.clickSubmitButton();
    expect(page.getCurrentURL()).toContain('dashboard/view/noteview');
  });*/

  it('Menu slider Functionality', () => {
    note.navigateToNoteView();
    element(by.css("button[type=menuslide]")).click();
    expect(element((by.id('menutext'))).getText()).toEqual('MENU');
    expect(page.getCurrentURL()).toContain('dashboard/view/noteview');
  });

  it('Category Creation', () => {
    element(by.css("button[type=categorybutton]")).click();
    element(by.id('categoryname')).sendKeys('Home');
    element(by.id('categorydesc')).sendKeys('My Home');
    element(by.css("button[type=categorysubmit]")).click();
    // browser.sleep(3000);
  });

  it('Category Updation', () => {
    element(by.className('loadcategory')).click();
    const categoryElement = element.all(by.className('edit'));
    categoryElement.last().click();
    // element(by.className('edit')).click();
    element(by.id('editCategoryName')).sendKeys(' 123');
    element(by.id('editCategoryDesc')).sendKeys(' At Street 123');
    element(by.css("button[type=categoryupdate]")).click();
    // browser.sleep(30000);
  });

  it('Category Deletion', () => {
    element(by.className('loadcategory')).click();
    const categoryElement = element.all(by.css("button[type=categorydeletebutton]"));
    categoryElement.last().click();
    // element(by.css("button[type=categorydeletebutton]")).click();
  });


});