import { LoginPage } from './page-objects/login.po';
import { browser, by, element, ElementFinder, promise, protractor } from 'protractor';
import { NoteViewPage } from './page-objects/noteview.po';

describe('Reminder page', () => {
  let page: LoginPage;
  let note: NoteViewPage;
  beforeEach(() => {
    page = new LoginPage();
    note = new NoteViewPage();
  });

  /*it('Login --> Display Notes View', () => {
    page.navigateToLogin();
    let newNoteValues = page.addLoginValues();
    expect(page.getLoginInputBoxesDefaultValues()).toEqual(newNoteValues, 'Should be able to set values for username and password');
    page.clickSubmitButton();
    expect(page.getCurrentURL()).toContain('dashboard/view/noteview');
  });

  it('Menu slider Functionality', () => {
      note.navigateToNoteView();
      element(by.css("button[type=menuslide]")).click();
      expect(element((by.id('menutext'))).getText()).toEqual('MENU');   
      expect(page.getCurrentURL()).toContain('dashboard/view/noteview');
    });*/

  it('Reminder Creation', () => {
    element(by.css("button[type=reminderbutton]")).click();
    element(by.id('remindername')).sendKeys('Voice Mail');
    element(by.id('reminderdesc')).sendKeys('Remind me at 7');
    element(by.id('remindertype')).sendKeys('Daily');
    element(by.css("button[type=remindersubmit]")).click();
    // browser.sleep(3000);
  });

  it('Reminder Updation', () => {
    element(by.className('loadreminder')).click();
    const reminderElement = element.all(by.className('editreminder'));
    reminderElement.last().click();
    // element(by.className('editreminder')).click();
    element(by.id('editreminderName')).sendKeys(' Notification');
    element(by.id('editreminderDesc')).sendKeys(' Get Notified');
    element(by.id('editreminderType')).sendKeys(' and Weekly');
    element(by.css("button[type=reminderupdate]")).click();
    // browser.sleep(30000);
  });

  it('Reminder Deletion', () => {
    element(by.className('loadreminder')).click();
    const reminderElement = element.all(by.css("button[type=reminderdeletebutton]"));
    reminderElement.last().click();
    // element(by.css("button[type=reminderdeletebutton]")).click();
  });


}); 