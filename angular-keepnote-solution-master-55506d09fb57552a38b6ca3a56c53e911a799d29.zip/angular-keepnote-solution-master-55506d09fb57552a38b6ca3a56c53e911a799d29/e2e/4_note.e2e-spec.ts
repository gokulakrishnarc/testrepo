import { NoteViewPage } from './page-objects/noteview.po';
import { browser, by, element, ElementFinder, promise, protractor } from 'protractor';
//add fdescribe to run specific test
describe('Note page', () => {
  let page: NoteViewPage;
  const emptyNoteValues = ['', ''];
  const editNoteDefaultValues = ['Read Angular 5 blog', 'Shall do at 6 pm', 'not-started'];
  const editNote = ['Read Angular 1 blog', 'Shall do at 10.30 pm', 'not-started'];

  beforeEach(() => {
    page = new NoteViewPage();
  });

  it('Note Creation', () => {
    page.navigateToNoteView();
    page.getNotePanel().click();
    expect(page.getNotePanelDefaultValues()).toEqual(emptyNoteValues, 'Default values for title and text should be empty');
    const newNoteValues = page.addNoteValues();
    expect(page.getNotePanelDefaultValues()).toEqual(newNoteValues, 'Should be able to set values for note title and text');
    page.clickDoneButton();
  });

  it('Render edit note popup on clicking on note', () => {
    page.navigateToNoteView();
    page.clickLastNote();
    expect(page.isEditTitleInputBoxPresent()).toBeTruthy('Title input box should exist with name attribute as editTitle');
    expect(page.isEditTextInputBoxPresent()).toBeTruthy('Text input box should exist with name attribute as editText');
    expect(page.isEditStatusInputBoxPresent()).toBeTruthy('Status select box should exist with name attribute as editStatus');
    expect(page.isSaveButtonPresent()).toBeTruthy('Save button exists with Save text');
    expect(page.getLastNoteTitle()).toBe(page.getMockNote().title,
      'Added note title should be shown in <mat-card-title> element on note.component.html');
  });

  it('Note Updation', () => {
    page.navigateToNoteView();
    page.clickLastNote();
    expect(page.isEditTitleInputBoxPresent()).toBeTruthy('Title input box should exist with name attribute as editTitle');
    expect(page.isEditTextInputBoxPresent()).toBeTruthy('Text input box should exist with name attribute as editText');
    expect(page.isEditStatusInputBoxPresent()).toBeTruthy('Status select box should exist with name attribute as editStatus');
    expect(page.isSaveButtonPresent()).toBeTruthy('Save button exists with Save text');
    expect(page.getEditNoteDefaultValues()).toEqual(editNoteDefaultValues, 'Default values should be shown on edit note dialog');
    const editNoteValues = page.editNoteValues();
    expect(page.getEditNoteDefaultValues()).toEqual(editNoteValues, 'Should be able to set values for note title and text');
    page.clickSaveButton();
    expect(page.getLastNoteTitle()).toEqual(editNote[0],
      'Edited note title should be shown in <mat-card-title> element on note.component.html');
  });

  it('Note Deletion', () => {
    // page.getLastNote().element(by.id("deletematicon")).click
    page.getLastNote().element(by.css('mat-icon')).click

  });

});