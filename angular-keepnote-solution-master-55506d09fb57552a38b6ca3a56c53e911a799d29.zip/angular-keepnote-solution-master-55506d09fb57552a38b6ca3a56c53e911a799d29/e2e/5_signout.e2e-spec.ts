import { LoginPage } from './page-objects/login.po';
import { browser, by, element, ElementFinder, promise, protractor } from 'protractor';
import { NoteViewPage } from './page-objects/noteview.po';

describe('logout page', () => {
  let page: LoginPage;
  let note: NoteViewPage;

  beforeEach(() => {
    page = new LoginPage();
    note = new NoteViewPage();
  });

  /* it('should login into the system, notes view is displayed', () => {
     page.navigateToLogin();
     let newNoteValues = page.addLoginValues();
     expect(page.getLoginInputBoxesDefaultValues()).toEqual(newNoteValues, 'Should be able to set values for username and password');
     page.clickSubmitButton();
     expect(page.getCurrentURL()).toContain('dashboard/view/noteview');
   }); */

  it('should logout, redirect to login page', () => {
    note.navigateToNoteView();
    element(by.css("button[type=signout]")).click();
    expect(page.getCurrentURL()).toContain('login');
  });
}); 