import { Component } from '@angular/core';
import { RouterService } from '../services/router.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  isNoteView = true;
  constructor(private router: RouterService) { }

  routeToListView() {
    this.router.routeToListView();
    this.isNoteView = false;
  }
  routeToNoteView() {
    console.log('this.isNoteView on routenoteview', this.isNoteView);
    this.router.routeToNoteView();
    this.isNoteView = true;
  }
}
