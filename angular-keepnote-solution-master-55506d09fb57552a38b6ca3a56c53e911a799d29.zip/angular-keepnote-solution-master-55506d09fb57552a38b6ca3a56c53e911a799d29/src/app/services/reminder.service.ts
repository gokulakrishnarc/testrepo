import { Injectable } from '@angular/core';
import { Reminder } from '../create-reminder/reminder';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './authentication.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable()
export class ReminderService {
  reminder: Reminder;
  reminders: Array<Reminder>;
  remindersSubject: BehaviorSubject<Array<Reminder>>;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) { 
    this.reminders = [];
    this.remindersSubject = new BehaviorSubject([]);
    this.reminder = new Reminder();
  }

  fetchRemindersFromServer() {
    console.log('inside fetchRemindersFromServer');
    if(this.authService.getUserId() !== null){
      this.httpClient.get<Reminder[]>(`http://localhost:8082/api/v1/reminder`, {
        headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
      }).subscribe(remindersResponse => {
        this.reminders = remindersResponse;
        this.remindersSubject.next(this.reminders);
      });
    }else{
      console.log('No User Loggedin');
    } 
  }

getReminders(): BehaviorSubject<Array<Reminder>> {
    return this.remindersSubject;
  }

 addReminder(reminder: Reminder): Observable<Reminder> {
  reminder.reminderCreatedBy = this.authService.getUserId();
  console.log('inside addReminder req=> ', reminder)
  return this.httpClient.post<Reminder>('http://localhost:8082/api/v1/reminder', reminder, {
    headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
  }).do(addReminders => {
    console.log('after addReminders in do', addReminders)
    this.reminders.push(addReminders);
    this.remindersSubject.next(this.reminders);
  });
}

deleteReminder(reminder: Reminder){
  console.log('inside deleteReminder=> ', reminder);
  return this.httpClient.delete(`http://localhost:8082/api/v1/reminder/${reminder.reminderId}`,
  {
    headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
  }).do(deleteReminder => {
    console.log('inside deleteReminder', deleteReminder)
    const index = this.reminders.findIndex(deleteReminder => deleteReminder.id === reminder.reminderId);
    this.reminders.splice(index, 1);
    this.remindersSubject.next(this.reminders);
  });
}

getReminderById(reminder: Reminder){
  console.log('inside getReminderById=> ', reminder);
  return this.httpClient.get<Reminder>(`http://localhost:8082/api/v1/reminder/${reminder.id}`,
  {
    headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
  });
}

getReminderFromId(reminderId: String): Reminder {
  return this.reminders.find(reminder => reminder.reminderId === reminderId);
}

getReminderFromName(reminderName: String): Reminder {
  return this.reminders.find(reminder => reminder.reminderName === reminderName);
}

editReminder(reminder: Reminder): Observable<Reminder> {
  console.log('inside editReminder=> ', reminder);
  return this.httpClient.put<Reminder>(`http://localhost:8082/api/v1/reminder/${reminder.reminderId}`, reminder, {
    headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
  }).pipe(
    tap(editedReminder => {
      const reminderObj = this.reminders.find(data => data.id === editedReminder.reminderId);
      Object.assign(reminderObj, editedReminder);
      this.remindersSubject.next(this.reminders);
    })
  );
}

}
