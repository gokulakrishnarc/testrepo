import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { log } from 'util';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  submitMessage: String;
  private bearerToken: any;
  constructor(private authService: AuthenticationService, private routerService: RouterService) { }
  username = new FormControl('', Validators.compose([Validators.required, Validators.minLength(5)]));
  password = new FormControl('', Validators.compose([Validators.required, Validators.minLength(5)]));

  loginSubmit() {
    //const formValue = {username: this.username.value, password: this.password.value};

    this.authService.authenticateUser(this.username.value, this.password.value).subscribe(res => {
      //this.authService.authenticateUser(formValue).subscribe(res => {
      console.log('res', res['token']);
      console.log('UserId', res['UserId']);
      this.authService.setBearerToken(res['token']);
      this.authService.setUserId(res['UserId']);
      console.log('before route guard');
      this.routerService.routeToDashboard();
    },
      err => {
        this.submitMessage = 'Unauthorized';
      }
    );
  }

  userSignup() {
    console.log('redirecting to userSignup');
    this.routerService.routeToSignUp();
  }

}



