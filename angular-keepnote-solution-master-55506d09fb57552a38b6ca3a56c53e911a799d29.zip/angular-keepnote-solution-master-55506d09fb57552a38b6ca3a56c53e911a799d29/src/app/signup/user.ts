export class User {
    public userId: string;
    public userPassword: string;
    public firstName: string;
    public lastName: string;
    public userRole: string;
    public userMobile: string;
    public isChecked: boolean;
    public userName: string;
    public userAddedDate: Date;
}
