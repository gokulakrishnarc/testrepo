import { Category } from "./create-category/category";
import { Reminder } from "./create-reminder/reminder";

export class Note {
  noteId: Number;
  noteTitle: string;
  noteContent: string;
  noteStatus: string;
  noteCreatedBy: string;
  category: Category;
  reminders: Array<Reminder>;

  // constructor() {
  //   this.noteTitle = '';
  //   this.noteContent = '';
  //   this.noteStatus = 'not-started';
  // }
}
