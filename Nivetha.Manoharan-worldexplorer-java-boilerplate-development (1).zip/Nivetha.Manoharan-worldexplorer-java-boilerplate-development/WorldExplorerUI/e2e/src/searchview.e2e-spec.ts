import { SearchViewPage } from './searchview.po';
import { browser, by, element, ElementFinder, promise, protractor } from 'protractor';

describe('Search panel:', () => {
    let page: SearchViewPage;

    beforeEach(() => {
        page = new SearchViewPage();
    });
    

      it('should list the countries', () => {
        page.navigateToSearch();
        expect(page.isUserNameInputBoxPresent())
        .toBeTruthy(`<<mat-card class="card" *ngFor="let det of cdetails'> should exist in search-view.component.html`);
      });
      
      
});

