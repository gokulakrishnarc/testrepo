import { SearchPage } from './search.po';
import { browser, by, element, ElementFinder, promise, protractor } from 'protractor';

describe('Search panel:', () => {
    let page: SearchPage;

    beforeEach(() => {
        page = new SearchPage();
    });
    

      it('should have search input box', () => {
        page.navigateToSearch();
        expect(page.isUserNameInputBoxPresent())
        .toBeTruthy(`<input matInput  name="title'> should exist in search-panel.component.html`);
      });
      it('should have Search button', () => {
        page.navigateToSearch();
        expect(page.isSubmitButtonPresent())
        .toBeTruthy(`<button mat-button (click)="takeNote()'> should exist in search-panel.component.html`);
      });
      
});

