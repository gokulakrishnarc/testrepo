import { LoginPage } from './login.po';
import { browser, by, element, ElementFinder, promise, protractor } from 'protractor';

describe('New User Registration Functionality :', () => {
    let page: LoginPage;

    beforeEach(() => {
        page = new LoginPage();
    });
    

});

