import { Component, OnInit } from '@angular/core';

import { SearchService } from '../services/search.service';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Cdetail } from '../cdetail';
import { Favourite } from '../favourite';
import { FavouriteService } from '../services/favourite.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-search-view',
  templateUrl: './search-view.component.html',
  styleUrls: ['./search-view.component.css']
})
export class SearchViewComponent implements OnInit {


   cdetails:  Array<Cdetail>;
  
  errMessage: string;
  response: string;
  favourite: Favourite;
 
 
  constructor(private searchService: SearchService, private authService: AuthenticationService,private favouriteservice: FavouriteService) {
    this.favourite = new Favourite();
  }

  ngOnInit() {
   
    this.searchService.fetchDetails().subscribe(resp=> {
      console.log('fetchdetails from  view comp.....'+resp);
    this.cdetails=resp;}
  )
  }
   // Favourite creation on click on save button along with validation
  saveFavourite(countryname:string) { 
    console.log('save remainder....'+countryname)   
    this.favourite.favouriteName = countryname;
    this.favourite.favouriteCreatedBy = this.authService.getUserId();
      this.favouriteservice.addFavourite(this.favourite).subscribe(addedFav => {
        this.response = 'Added Succesfully';
      }, err => {
        this.errMessage = err.message;
      
      });
    }

}
