import { Component, OnInit } from '@angular/core';

import { SearchService } from '../services/search.service';
import { Country } from '../country';
import { RouterService } from '../services/router.service'

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.css']
})
export class ListViewComponent implements OnInit {

 
  countries:Array<Country>;

  constructor(private searchService: SearchService,private routerService: RouterService) { }

  ngOnInit() {
    this.searchService.fetchMatches().subscribe(resp=> {
      console.log('fetchMatches from  List comp.....'+resp);
    this.countries=resp;} )
  }
 
 
  openCountryFromList(countryName:string) {
    console.log("openCountryFrom List....."+countryName);
   this.searchService.getCountryDetail(countryName);
   this.routerService.routeToEditNoteView1();
   
  }
}
