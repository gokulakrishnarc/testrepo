import { Component, OnInit, Input } from '@angular/core';

import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';
import { FavouriteService } from '../services/favourite.service';
import { Favourite } from '../favourite';

@Component({
  selector: 'app-favourite-list',
  templateUrl: './favourite-list.component.html',
  styleUrls: ['./favourite-list.component.css']
})
export class FavouriteListComponent implements OnInit {
  @Input()
  favourite: Favourite;
  favourites:Array<Favourite>;

  constructor(private favouriteService: FavouriteService) { }

  ngOnInit() {
    this.favouriteService.getFavourites().subscribe(resp=> {
     this.favourites = resp;
    });
  }
}
