import { Component, OnInit, ViewChild } from '@angular/core';

import { SearchService } from '../services/search.service';

import { FormControl } from '@angular/forms';
import { Country } from '../country';
import { error } from 'selenium-webdriver';
import { RouterService } from '../services/router.service'

@Component({
  selector: 'app-search-panel',
  templateUrl: './search-panel.component.html',
  styleUrls: ['./search-panel.component.css']
})
export class SearchPanelComponent implements OnInit {
  errMessage: string;
  response: string;

  country: Country;

  //favourite: Favourite;

  constructor(private searchService: SearchService, private routerService: RouterService) {

    //this.favourite = new Favourite();

    this.country = new Country();
  }

  ngOnInit() {

    /*    this.favouriteService.fetchfavouritesFromServer();
        this.favouriteService.getFavourites().subscribe(favourite => {
          this.favouritesforView = favourite;
        });*/

  }


  takeNote() {

    this.searchService.getSearchCountry(this.country.countryname);
    this.routerService.routeToListCountryView();
  }

  openCountry() {
    console.log("openCountry.....");
    this.searchService.getCountryDetail(this.country.countryname);
    this.routerService.routeToEditNoteView1();

  }

}
