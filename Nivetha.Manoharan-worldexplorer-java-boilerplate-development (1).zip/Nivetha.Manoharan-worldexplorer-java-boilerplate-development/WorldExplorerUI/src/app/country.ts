export class Country { 
  countryname: string;
}