import { Injectable } from '@angular/core';
import { Favourite} from '../favourite';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './authentication.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import 'rxjs/add/operator/do';
@Injectable({
  providedIn: 'root'
})
export class FavouriteService {

  favourite: Favourite;
  favourites: Array<Favourite>;
  favouriteSubject: BehaviorSubject<Array<Favourite>>;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {
    this.favourites = [];
    this.favouriteSubject = new BehaviorSubject([]);
    this.favourite = new Favourite();
  }
  // Get favourite list from DB
  fetchFavouriteFromServer() {
    if (this.authService.getUserId() !== null) {
      console.log('fetch fav'+this.authService.getUserId());
      this.httpClient.get<Favourite[]>(`http://localhost:8082/api/v1/favourite/${this.authService.getUserId()}`, {
        headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
      }).subscribe(response1 => {
        this.favourites = response1;
        this.favouriteSubject.next(this.favourites);
      });
    } else {
    }
  }
  addFavourite(favourite: Favourite): Observable<Favourite> {
    favourite.favouriteCreatedBy = this.authService.getUserId();
    return this.httpClient.post<Favourite>('http://localhost:8082/api/v1/favourite', favourite, {
      headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(addfavs => {
      this.favourites.push(addfavs);
      this.favouriteSubject.next(this.favourites);
    });
  }
  // Behavior sub for favourite list
  getFavourites(): BehaviorSubject<Array<Favourite>> {
    return this.favouriteSubject;
  }
 

}
