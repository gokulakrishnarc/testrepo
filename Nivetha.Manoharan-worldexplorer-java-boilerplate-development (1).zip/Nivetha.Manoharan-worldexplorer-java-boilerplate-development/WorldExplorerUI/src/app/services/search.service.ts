import { Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './authentication.service';
import { tap } from 'rxjs/operators';
import 'rxjs/add/operator/do';
import { Country } from '../country';
import { Cdetail } from '../cdetail';

@Injectable({
  providedIn: 'root'
})
export class SearchService {


  country: Country;
  cdetail: Cdetail;
  cdetails: Array<Cdetail>;
  countries: Array<Country>;
  countryDet: BehaviorSubject<Array<Cdetail>>;
  countryList: BehaviorSubject<Array<Country>>;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {
   
    this.countryDet = new BehaviorSubject([]);
    this.countryList = new BehaviorSubject([]);
  }
  
  // To add note to DB
  getSearchCountry1(countryname: String) {
    console.log('getSearchCountry cuntry name: ' + countryname);
    return this.httpClient.get<Country>(`http://localhost:8080/api/v1/country/${countryname}`,{
      headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
    });
  }
  // To add note to DB
  getCountryDetail1(countryname: String) {
    console.log('getCountryDetail cuntry name: ' + countryname);
    return this.httpClient.get<Country>(`http://localhost:8080/api/v1/countrydetails/${countryname}`,{
      headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
    });
  }

  // To add note to DB
  getSearchCountry(countryname: String) {
    console.log('getSearchCountry cuntry name: ' + countryname);

    this.httpClient.get<Country[]>(`http://localhost:8080/api/v1/country/${countryname}`,{
      headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).subscribe(notesResponse => {
      this.countries = notesResponse;
      console.log('getSearchCountry......' + notesResponse);;
      this.countryList.next(this.countries);
    }, err => {

    });
  }
  fetchMatches(): BehaviorSubject<Array<Country>> {
    console.log('fetchMatches.........' + this.countryList);
    return this.countryList;
  }
  getCountryDetail(countryname: String) {
    console.log('getCountryDetail......');;
    this.httpClient.get<Cdetail[]>(`http://localhost:8080/api/v1/countrydetails/${countryname}`,{
      headers: new HttpHeaders().set('authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).subscribe(notesResponse => {
      this.cdetails = notesResponse;
      console.log('getCountryDetail......' + notesResponse);;
      this.countryDet.next(this.cdetails);
    }, err => {

    });
  }
  fetchDetails(): BehaviorSubject<Array<Cdetail>> {
    console.log('fetchDetails.........' + this.countryDet);
    return this.countryDet;
  }
}
