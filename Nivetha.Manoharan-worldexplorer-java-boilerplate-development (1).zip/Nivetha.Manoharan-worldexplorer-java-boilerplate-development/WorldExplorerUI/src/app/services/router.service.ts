import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Injectable()
export class RouterService {
  constructor(public router: Router,
    private location: Location) { }
  // Routing to Dashboard
  routeToDashboard() {
    this.router.navigate(['dashboard']);
  }
  // Routing to login
  routeToLogin() {
    this.router.navigate(['login']);
  }

  // Navigation route to ListCountryView
  routeToListCountryView() {
    console.log('routeToListCountryView')
    this.router.navigate(['dashboard/view/listview']);
  }
  // Navigation route to list details
  routeToEditNoteView1() {
    console.log('Router to list details')
    this.router.navigate(['dashboard/view/searchview']);
  }
  
  // For Stay back notes
  routeBack() {
    this.location.back();
  }
  // For List View
  routeToListView() {
    this.router.navigate(['dashboard/view/listview']);
  }
  // For Note View
  routeToNoteView() {
    this.router.navigate(['dashboard/view/searchview']);
  }
  // Routing to Registration page
  routeToSignUp() {
    this.router.navigate(['signup']);
  }
 
}
