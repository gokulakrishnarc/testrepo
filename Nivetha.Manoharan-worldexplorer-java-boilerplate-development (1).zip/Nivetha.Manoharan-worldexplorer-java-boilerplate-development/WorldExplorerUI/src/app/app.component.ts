import { Component, OnInit } from '@angular/core';
import { RouterService } from './services/router.service';


import { AuthenticationService } from './services/authentication.service';
import { FavouriteService } from './services/favourite.service';
import { Favourite } from './favourite';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title="WorldExplorerUI";

  events: string[] = [];
  opened: boolean;
  favourite:Favourite;
  favourites:Array<Favourite>;
 
  constructor(public routerService: RouterService,  private authService: AuthenticationService,private favouriteService:FavouriteService) {
  
  }
   ngOnInit() {
    this.loadFavourite();

  }
 
  
 
  
  loadFavourite() {
    this.favouriteService.fetchFavouriteFromServer();
    this.favouriteService.getFavourites().subscribe(favourite => {
      console.log('LoadFavv..'+favourite);
      this.favourites = favourite;
      console.log('this.favourites..'+this.favourites);
    });
  }
  

}
