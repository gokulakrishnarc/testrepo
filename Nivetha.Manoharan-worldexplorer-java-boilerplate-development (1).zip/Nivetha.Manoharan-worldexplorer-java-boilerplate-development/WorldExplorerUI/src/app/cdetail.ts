
export class Cdetail {
  countryname: string;
  capital: string;
  region: string;
  subregion: string;
  population: Number;
  demonym: string;
}
