// favourite property values
export class Favourite {
  id: String;
  favouriteName: String;
  favouriteDescription: String;
  favouriteType: String;
  favouriteCreatedBy: String;
  favouriteCreationDate: Date;
  favouriteId: String;
}
