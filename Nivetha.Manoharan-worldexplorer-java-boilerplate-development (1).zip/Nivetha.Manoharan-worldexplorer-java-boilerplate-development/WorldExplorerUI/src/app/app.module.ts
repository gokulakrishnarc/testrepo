import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LayoutModule } from '@angular/cdk/layout';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './signup/signup.component';
import { MatToolbarModule, MatSidenavModule, MatIconModule, MatListModule} from '@angular/material';
import {ReactiveFormsModule} from '@angular/forms';
import { AuthenticationService } from './services/authentication.service';
import { RouterService } from './services/router.service';
import { SearchService } from './services/search.service';
import { UserService } from './services/user.service';

import { FormsModule} from '@angular/forms';
import {MatCardModule} from '@angular/material/card';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';

import { HttpClientModule } from '@angular/common/http';
import { SearchPanelComponent } from './search-panel/search-panel.component';
import { CanActivateRouteGuard } from './can-activate-route.guard';
import { HeaderComponent } from './header/header.component';
import { SearchViewComponent } from './search-view/search-view.component';
import { ListViewComponent } from './list-view/list-view.component';
import { FavouriteListComponent } from './favourite-list/favourite-list.component';
const appRoutes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'login', component: LoginComponent }, 
  { path: 'signup', component: SignupComponent},
  { path: 'dashboard', component: DashboardComponent, canActivate: [CanActivateRouteGuard],
  children: [
    {
      path: '', redirectTo: 'view/searchview', pathMatch: 'full' // URL path of noteview through dashboard URL
    },
    {
      path: 'view/listview', component: ListViewComponent, // URL path of edit based on id
      
    },
    {
      path: 'view/searchview', component: SearchViewComponent // URL path of noteview
    },
    {
      path: 'view/listdetails', component: SearchViewComponent, // URL path of edit based on id
      
    },
    {
      path: '', redirectTo: 'view/searchview', pathMatch: 'full' // URL path of noteview through dashboard URL
    }
  ]
 }
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    SignupComponent,
    SearchPanelComponent,
    HeaderComponent,
    SearchViewComponent,
    ListViewComponent,
    FavouriteListComponent,
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    LayoutModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatButtonModule,
    
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
  
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    SearchService,
    AuthenticationService,
    CanActivateRouteGuard,
    RouterService,
   
    UserService,
   
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
