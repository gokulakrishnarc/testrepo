package com.stackroute.userservice.aspectj;

import java.util.Arrays;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/* Annotate this class with @Aspect and @Component */
@Aspect
@Component
public class LoggingAspect {
	
	
	private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

	@Before("execution(* com.stackroute.userservice.controller.*.*(..))")
	public void before(JoinPoint joinPoint) {
		logger.info("==============@Before==============");
		logger.debug("method name : " + joinPoint.getSignature().getName());
		logger.debug("***************At last line of @Before*******************");
	}

	@After("execution(* com.stackroute.userservice.controller.*.*(..))")
	public void after(JoinPoint joinPoint) {
		logger.info("==============@After==============");
		logger.debug("method name : " + joinPoint.getSignature().getName());
		logger.debug("method name : " + Arrays.toString(joinPoint.getArgs()));
		logger.debug("***************At last line of @After*******************");
	}

	@AfterReturning(pointcut = "execution(* com.stackroute.userservice.controller.*.*(..))", returning = "result")
	public void afterReturning(JoinPoint joinPoint) {
		logger.info("==============@AfterReturning==============");
		logger.debug("method name : " + joinPoint.getSignature().getName());
		logger.debug("method name : " + Arrays.toString(joinPoint.getArgs()));
		logger.debug("**************At last line of @AfterReturning********************");
	}

	@AfterThrowing(pointcut = "execution(* com.stackroute.userservice.controller.*.*(..))", throwing = "error")
	public void afterThrowing(JoinPoint joinPoint, Throwable error) {
		logger.info("==============@AfterThrowing==============");
		logger.debug("method name : " + joinPoint.getSignature().getName());
		logger.debug("Exception : " + error);
		logger.debug("****************At last line of @AfterThrowing******************");
	}
}