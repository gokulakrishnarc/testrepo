package com.stackroute.country.CountryService;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.stackroute.country.controller.CountryController;
import com.stackroute.country.domain.Country;
import com.stackroute.country.domain.Countrydetail;
import com.stackroute.country.service.CountryService;
import com.stackroute.country.service.CountryServiceImpl;

import junit.framework.Assert;



public class CountryServiceApplicationTest 
   
{
	@InjectMocks
    CountryServiceImpl countyService;

    Country country;
    Countrydetail countrydetail;
    List<Country> countryList =new ArrayList<Country>();
    
    List<Countrydetail> countryDetailsList =new ArrayList<Countrydetail>();
  
    Optional<Country> options;
    @Mock
    RestTemplate restTemplate;
    
	@Before
    public void setUp()
    {
        MockitoAnnotations.initMocks(this);
        country = new Country();
        country.setCountryname("indi");
        countryList = new ArrayList<Country>();
        countryList.add(country);
        options = Optional.of(country);
        
    }

	
	@Test
	public void testSearchcountry() {
		List<Country> countryListdata =countyService.searchcountry("india");
         assertNotNull(countryListdata);
	}

	@Test
	public void testCountrydetails() {		
		Countrydetail countryListdata =countyService.countrydetails("india");
         assertNotNull(countryListdata);
	}
	
    
  
    
}
