package com.stackroute.country.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.stackroute.country.domain.Country;
import com.stackroute.country.domain.Countrydetail;

public class CountryControllerTest {
	@InjectMocks
    CountryController countryRepo;

    Country country;
    Countrydetail countrydetail;
    List<Country> countryList =new ArrayList<Country>();
    
    List<Countrydetail> countryDetailsList =new ArrayList<Countrydetail>();
  
    Optional<Country> options;
    @Mock
    RestTemplate restTemplate;
    
	@Before
    public void setUp()
    {
        MockitoAnnotations.initMocks(this);
        country = new Country();
        country.setCountryname("indi");
        countryList = new ArrayList<Country>();
        countryList.add(country);
        options = Optional.of(country);
        
    }

	
	@Test
	public void testSearchcountry() {
		ResponseEntity<List<Country>> resp1 =new ResponseEntity(countryList,HttpStatus.ACCEPTED) ;
		when(restTemplate.exchange(Matchers.anyString(),Matchers.any(HttpMethod.class),
				Matchers.<HttpEntity<?>> any(),Matchers.<Class<List<Country>>> any())).thenReturn(resp1);
		 //when(countryService.searchcountry("india")).thenReturn(resp1);
		ResponseEntity<List<Country>> countryListdata =countryRepo.searchcountry("india");
         assertNotNull(countryListdata);
	}

	@Test
	public void testCountrydetails() {
		ResponseEntity<List<Countrydetail>> resp2 =new ResponseEntity(countryDetailsList,HttpStatus.ACCEPTED) ;
		when(restTemplate.exchange(Matchers.anyString(),Matchers.any(HttpMethod.class),
				Matchers.<HttpEntity<?>> any(),Matchers.<Class<List<Countrydetail>>> any())).thenReturn(resp2);
		 //when(countryService.searchcountry("india")).thenReturn(resp1);
		ResponseEntity<List<Countrydetail>> countryListdata =countryRepo.countrydetails("india");
         assertNotNull(countryListdata);
	}
	
}
