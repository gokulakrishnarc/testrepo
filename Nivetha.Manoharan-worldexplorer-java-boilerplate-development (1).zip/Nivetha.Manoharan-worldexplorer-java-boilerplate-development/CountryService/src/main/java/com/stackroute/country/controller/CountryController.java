package com.stackroute.country.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.country.domain.Country;
import com.stackroute.country.domain.CountryDomain;
import com.stackroute.country.domain.Countrydetail;
import com.stackroute.country.service.CountryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/*
 * As in this assignment, we are working on creating RESTful web service, hence annotate
 * the class with @RestController annotation. A class annotated with the @Controller annotation
 * has handler methods which return a view. However, if we use @ResponseBody annotation along
 * with @Controller annotation, it will return the data directly in a serialized 
 * format. Starting from Spring 4 and above, we can use @RestController annotation which 
 * is equivalent to using @Controller and @ResposeBody annotation
 */
@RestController
@Api
@CrossOrigin(origins = "*") // Means to that get URL access with no address specification
public class CountryController {
	/*
	 * Autowiring should be implemented for the UserService. (Use Constructor-based
	 * autowiring) Please note that we should not create an object using the new
	 * keyword
	 */
	CountryService countryService;

	@Autowired
	public CountryController(CountryService countryService) {
		this.countryService = countryService;
	}

	/*
	 * Define a handler method which will create a specific user by reading the
	 * Serialized object from request body and save the user details in the
	 * database. This handler method should return any one of the status messages
	 * basis on different situations: 1. 201(CREATED) - If the user created
	 * successfully. 2. 409(CONFLICT) - If the userId conflicts with any existing
	 * user
	 * 
	 * This handler method should map to the URL "/user" using HTTP POST method
	 */

	@ApiOperation(value = "Search Country") // For swagger UI Name of Api
	@GetMapping(value = "/api/v1/country/{searchtxt}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Country>> searchcountry(@PathVariable("searchtxt") String searchtxt) {
		Country country = new Country();
		List<Country> resp = null;
		try {
			resp = countryService.searchcountry(searchtxt);
			//country.setCountryname(resp);
		} catch (Exception e) {
		}
		if (resp == null) {
			return new ResponseEntity<List<Country>>(HttpStatus.NOT_FOUND);// For -ve case
		}
		return new ResponseEntity<List<Country>>(resp, HttpStatus.OK);
	}

	@ApiOperation(value = "Get Details") // For swagger UI Name of Api
	@GetMapping(value = "/api/v1/countrydetails/{searchtxt}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Countrydetail>> countrydetails(@PathVariable("searchtxt") String searchtxt) {
		Countrydetail countryDet = new Countrydetail();
		List<Countrydetail> finalList= new ArrayList<Countrydetail>();
		
		try {
			countryDet = countryService.countrydetails(searchtxt);
			finalList.add(countryDet);
		} catch (Exception e) {
		}
		if (countryDet == null) {
			return new ResponseEntity<List<Countrydetail>>(HttpStatus.NOT_FOUND);// For -ve case
		}
		return new ResponseEntity<List<Countrydetail>>(finalList, HttpStatus.OK);
	}

}