package com.stackroute.country.service;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.stackroute.country.domain.Country;
import com.stackroute.country.domain.CountryDomain;
import com.stackroute.country.domain.Countrydetail;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */
@Service
public class CountryServiceImpl implements CountryService {

	public List<Country> searchcountry(String searchTxt) {
		List<String> finalList = new ArrayList<String>();

		RestTemplate resttemplate = new RestTemplate();
		HttpHeaders headers = buidheaders();

		HttpEntity<CountryDomain> entity = new HttpEntity<CountryDomain>(headers);
		ResponseEntity<String> response = null;
		String matchFound = "";
		Country country = new Country();
		List<Country> countryList = new ArrayList<Country>();
		//String url="https://restcountries.eu/rest/v2/all";
		String url="https://restcountries.eu/rest/v2/name/"+searchTxt;
		try {
			response = resttemplate.exchange(url, HttpMethod.GET, entity,
					String.class);
			if (response != null) {
				String json = "{message:" + response.getBody() + "}";
				org.json.JSONObject jsonObject = new org.json.JSONObject(json);
				JSONArray jsonArray = jsonObject.getJSONArray("message");
				for (int i = 0; i < jsonArray.length(); i++) {
					
					JSONObject namejsonObject = (JSONObject) jsonArray.get(i);
					if (namejsonObject != null) {
						String nnme = namejsonObject.getString("name");
						//if (nnme.contains(searchTxt)) {
							country = new Country();
							matchFound = nnme;
							country.setCountryname(matchFound);
							countryList.add(country);
						//}
						System.out.println("name--- " + nnme);
					}
					
				}
			}

		} catch (Exception e) {
			System.out.println("Expception e" + e);
		}
		return countryList;

	}

	private HttpHeaders buidheaders() {
		HttpHeaders headers = new org.springframework.http.HttpHeaders();
		// headers.add("Accept","application/json");
		return headers;
	}

	public Countrydetail countrydetails(String searchTxt) {
		Countrydetail countrydetail = new Countrydetail();

		RestTemplate resttemplate = new RestTemplate();
		HttpHeaders headers = buidheaders();

		HttpEntity<Countrydetail> entity = new HttpEntity<Countrydetail>(headers);
		ResponseEntity<String> response = null;
		String matchFound = "";
		String url="https://restcountries.eu/rest/v2/name/"+searchTxt;

		try {
			response = resttemplate.exchange(url, HttpMethod.GET, entity,
					String.class);
			if (response != null) {
				String json = "{message:" + response.getBody() + "}";
				org.json.JSONObject jsonObject = new org.json.JSONObject(json);
				JSONArray jsonArray = jsonObject.getJSONArray("message");
				for (int i = 0; i < jsonArray.length(); i++) {
					JSONObject namejsonObject = (JSONObject) jsonArray.get(i);
					if (namejsonObject != null) {
						String nnme = namejsonObject.getString("name");
						String capital = namejsonObject.getString("capital");
						String region = namejsonObject.getString("region");
						String subregion = namejsonObject.getString("subregion");						
						long population = namejsonObject.getLong("population");
						String demonym = namejsonObject.getString("demonym");
						if(nnme.equalsIgnoreCase(searchTxt)) {
						countrydetail.setCountryname(nnme);
						countrydetail.setRegion(region);
						countrydetail.setSubregion(subregion);
						countrydetail.setCapital(capital);
						countrydetail.setPopulation(population);
						countrydetail.setDemonym(demonym);
						}
					}
				}
			}

		} catch (Exception e) {
			System.out.println("Expception e" + e);
		}
		return countrydetail;
	}
}