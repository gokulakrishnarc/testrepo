package com.stackroute.country.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.stackroute.country.domain.Country;
import com.stackroute.country.domain.CountryDomain;
import com.stackroute.country.domain.Countrydetail;

public interface CountryService {

	
	List<Country> searchcountry(String searchTxt);
		Countrydetail countrydetails(String searchTxt);
}
