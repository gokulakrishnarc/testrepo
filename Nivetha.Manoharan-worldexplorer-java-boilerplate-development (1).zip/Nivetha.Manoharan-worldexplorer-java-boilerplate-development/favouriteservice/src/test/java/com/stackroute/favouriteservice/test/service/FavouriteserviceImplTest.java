package com.stackroute.favouriteservice.test.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.favouriteservice.exception.FavouriteNotCreatedException;
import com.stackroute.favouriteservice.model.Favourite;
import com.stackroute.favouriteservice.repository.FavouriteserviceRepository;
import com.stackroute.favouriteservice.service.FavouriteServiceImpl;

import junit.framework.Assert;

public class FavouriteserviceImplTest {

    @Mock
    FavouriteserviceRepository favouriteRepository;

    Favourite favourite;

    @InjectMocks
    FavouriteServiceImpl favouriteService;

    List<Favourite> favuriteList;
    Optional<Favourite> options;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks(this);
        favourite = new Favourite();

        favourite.setFavouriteCreatedBy("John123");
        favourite.setFavouriteCreationDate(new Date());
        favourite.setFavouriteDescription("Sending Emails");
        favourite.setFavouriteId("5b0509731764e3096984eae6");
        favourite.setFavouriteName("Email");
        favourite.setFavouriteType("Email type");
        favuriteList = new ArrayList<Favourite>();
        favuriteList.add(favourite);

        options = Optional.of(favourite);

    }

    @Test
    public void createFavouriteSuccess() throws FavouriteNotCreatedException
    {
        when(favouriteRepository.insert((Favourite) any())).thenReturn(favourite);
        Favourite favSaved = favouriteService.createFavourite(favourite);
        Assert.assertEquals(favourite, favSaved);

    }

    @Test(expected = FavouriteNotCreatedException.class)
    public void createFavouriteFailure() throws FavouriteNotCreatedException
    {
        when(favouriteRepository.insert((Favourite) any())).thenReturn(null);
        Favourite favSaved = favouriteService.createFavourite(favourite);
        Assert.assertEquals(favourite, favSaved);
    }

   
  

   


    @Test
    public void getAllFavourites()
    {
        when(favouriteRepository.findAll()).thenReturn(favuriteList);
        List<Favourite> favListdata = favouriteService.getAllFavourites();
        Assert.assertEquals(favuriteList, favListdata);

    }













}