package com.stackroute.favouriteservice.test.controller;



import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.favouriteservice.controller.FavouriteserviceController;
import com.stackroute.favouriteservice.exception.FavouriteNotCreatedException;
import com.stackroute.favouriteservice.exception.FavouriteNotFoundException;
import com.stackroute.favouriteservice.model.Favourite;
import com.stackroute.favouriteservice.service.FavouriteService;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@RunWith(SpringRunner.class)
@WebMvcTest
public class FavouriteserviceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private Favourite favourite;

    @MockBean
    private FavouriteService favouriteService;

    @InjectMocks
    private FavouriteserviceController favouriteController;

    private List<Favourite> favoList;


    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(favouriteController).build();
        favourite = new Favourite();
        favourite.setFavouriteCreatedBy("John123");
        favourite.setFavouriteCreationDate(new Date());
        favourite.setFavouriteDescription("Sending Emails");
        favourite.setFavouriteId("5b0509731764e3096984eae6");
        favourite.setFavouriteName("Email");
        favourite.setFavouriteType("Email type");
        favoList = new ArrayList<Favourite>();
        favoList.add(favourite);


    }

    @Test
    public void createFavouriteSuccess() throws Exception
    {
        when(favouriteService.createFavourite((Favourite) any())).thenReturn(favourite);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/favourite").contentType
                (MediaType.APPLICATION_JSON)
                .content(asJsonString(favourite)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andDo(MockMvcResultHandlers.print());

    }

    @Test
    public void createFavouriteFailure() throws Exception
    {
        when(favouriteService.createFavourite((Favourite) any())).thenThrow(FavouriteNotCreatedException.class);
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/favourite").
                contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(favourite)))
                .andExpect(MockMvcResultMatchers.status().isConflict())
                .andDo(MockMvcResultHandlers.print());


    }


    private static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}