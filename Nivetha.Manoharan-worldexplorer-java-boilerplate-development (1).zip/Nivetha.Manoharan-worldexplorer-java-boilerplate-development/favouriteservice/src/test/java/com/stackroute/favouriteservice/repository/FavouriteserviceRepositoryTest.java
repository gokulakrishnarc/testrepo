package com.stackroute.favouriteservice.repository;

import com.stackroute.favouriteservice.model.Favourite;
import com.stackroute.favouriteservice.repository.FavouriteserviceRepository;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@DataMongoTest
public class FavouriteserviceRepositoryTest {


    @Autowired
    private FavouriteserviceRepository favouriterepository;
    private Favourite favourite;

    @Before
    public void setUp() throws Exception {
    	favourite = new Favourite();
    	favourite.setFavouriteId("12sdcdc321xewxcw34");
    	favourite.setFavouriteName("Email favourite");
    	favourite.setFavouriteDescription("Sending email @ 5AM");
    	favourite.setFavouriteType("Daily favourite");
    	favourite.setFavouriteCreatedBy("Jhon123");
    	favourite.setFavouriteCreationDate(new Date());
    }

    @After
    public void tearDown() throws Exception {
    	favouriterepository.deleteAll();
    }

    @Test
    public void createFavouriteTest() {

    	favouriterepository.insert(favourite);
        Favourite favourite1 = favouriterepository.findById(favourite.getFavouriteId()).get();
        Assert.assertEquals(favourite.getFavouriteName(), favourite1.getFavouriteName());

    }

    @Test(expected = NoSuchElementException.class)
    public void deletefavouriteTest() {


        favouriterepository.insert(favourite);
        Favourite favourite1 = favouriterepository.findById(favourite.getFavouriteId()).get();
        favouriterepository.delete(favourite1);
        favourite1 = favouriterepository.findById(favourite.getFavouriteId()).get();
    }

    @Test
    public void updatefavouriteTest() {
        favouriterepository.insert(favourite);
        Favourite favourite1 = favouriterepository.findById(favourite.getFavouriteId()).get();
        favourite1.setFavouriteDescription("Sending emails @ 10AM");
        favouriterepository.save(favourite1);
        Assert.assertEquals("Sending emails @ 10AM", favourite1.getFavouriteDescription());


    }

    @Test
    public void getfavouriteByIdTest() {
        favouriterepository.insert(favourite);
        Favourite favourite1 = favouriterepository.findById(favourite.getFavouriteId()).get();
        Assert.assertEquals("Sending email @ 5AM", favourite1.getFavouriteDescription());


    }

    @Test
    public void getAllfavouriteTest() {
        favouriterepository.insert(favourite);

        favourite = new Favourite();
        favourite.setFavouriteId("12sdcdc321ded33333");
        favourite.setFavouriteName("SMA favourite");
        favourite.setFavouriteDescription("Sending SMS @ 5AM");
        favourite.setFavouriteType("Daily favourite");
        favourite.setFavouriteCreatedBy("Jhon123");
        favourite.setFavouriteCreationDate(new Date());
        favouriterepository.insert(favourite);

        List<Favourite> allfavourites = favouriterepository.findAll();
        Assert.assertEquals(2, allfavourites.size());

    }
}
