package com.stackroute.favouriteservice.service;

import java.util.List;

import com.stackroute.favouriteservice.exception.FavouriteNotCreatedException;
import com.stackroute.favouriteservice.model.Favourite;

public interface FavouriteService {
	
	/*
	 * Should not modify this interface. You have to implement these methods in
	 * corresponding Impl classes
	 */

    Favourite createFavourite(Favourite favourite) throws FavouriteNotCreatedException;

   
    List<Favourite> getAllFavourites();
}
