package com.stackroute.favouriteservice.exception;

public class FavouriteNotCreatedException extends Exception {
    
	private static final long serialVersionUID = 1L;

	public FavouriteNotCreatedException(String message) {
        super(message);
    }
}
