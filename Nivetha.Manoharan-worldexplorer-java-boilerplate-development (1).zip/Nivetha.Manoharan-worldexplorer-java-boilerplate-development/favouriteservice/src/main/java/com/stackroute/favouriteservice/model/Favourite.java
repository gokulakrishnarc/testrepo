package com.stackroute.favouriteservice.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/*
 * Please note that this class is annotated with @Document annotation
 * @Document identifies a domain object to be persisted to MongoDB.
 *  */
@Document
public class Favourite {

	/*
	 * This class should have six fields
	 * (favouriteId,favouriteName,favouriteDescription,favouriteType,
	 * favouriteCreatedBy,favouriteCreationDate). Out of these six fields, the field
	 * favouriteId should be annotated with @Id. This class should also contain the
	 * getters and setters for the fields along with the no-arg , parameterized
	 * constructor and toString method. The value of favouriteCreationDate should not
	 * be accepted from the user but should be always initialized with the system
	 * date.
	 */
	@Id
	private String favouriteId;
	private String favouriteName;
	private String favouriteDescription;
	private String favouriteType;
	private Date favouriteCreationDate;
	private String favouriteCreatedBy;

	public Favourite() {

	}

	public Favourite(String id, String string, String string1, String string2, String string3, Date date) {
		this.favouriteId = id;
		this.favouriteName = string;
		this.favouriteDescription = string1;
		this.favouriteType = string2;
		this.favouriteCreatedBy = string3;
		this.favouriteCreationDate = date;
	}


	@Override
	public String toString() {
		return "Favourite [favouriteId=" + favouriteId + ", favouriteName=" + favouriteName + ", favouriteDescription="
				+ favouriteDescription + ", favouriteType=" + favouriteType + ", favouriteCreationDate="
				+ favouriteCreationDate + ", favouriteCreatedBy=" + favouriteCreatedBy + "]";
	}

	public String getFavouriteId() {
		return favouriteId;
	}

	public void setFavouriteId(String favouriteId) {
		this.favouriteId = favouriteId;
	}

	public String getFavouriteName() {
		return favouriteName;
	}

	public void setFavouriteName(String favouriteName) {
		this.favouriteName = favouriteName;
	}

	public String getFavouriteDescription() {
		return favouriteDescription;
	}

	public void setFavouriteDescription(String favouriteDescription) {
		this.favouriteDescription = favouriteDescription;
	}

	public String getFavouriteType() {
		return favouriteType;
	}

	public void setFavouriteType(String favouriteType) {
		this.favouriteType = favouriteType;
	}

	public Date getFavouriteCreationDate() {
		return favouriteCreationDate;
	}

	public void setFavouriteCreationDate(Date favouriteCreationDate) {
		this.favouriteCreationDate = favouriteCreationDate;
	}

	public String getFavouriteCreatedBy() {
		return favouriteCreatedBy;
	}

	public void setFavouriteCreatedBy(String favouriteCreatedBy) {
		this.favouriteCreatedBy = favouriteCreatedBy;
	}
	
	
}
