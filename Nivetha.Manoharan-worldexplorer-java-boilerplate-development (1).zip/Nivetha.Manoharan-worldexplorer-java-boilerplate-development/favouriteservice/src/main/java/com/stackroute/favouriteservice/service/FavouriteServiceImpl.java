package com.stackroute.favouriteservice.service;

import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.stackroute.favouriteservice.exception.FavouriteNotCreatedException;
import com.stackroute.favouriteservice.exception.FavouriteNotFoundException;
import com.stackroute.favouriteservice.model.Favourite;
import com.stackroute.favouriteservice.repository.FavouriteserviceRepository;

/*
* Service classes are used here to implement additional business logic/validation 
* This class has to be annotated with @Service annotation.
* @Service - It is a specialization of the component annotation. It doesn't currently 
* provide any additional behavior over the @Component annotation, but it's a good idea 
* to use @Service over @Component in service-layer classes because it specifies intent 
* better. Additionally, tool support and additional behavior might rely on it in the 
* future.
* */
@Service
public class FavouriteServiceImpl implements FavouriteService {
	
	FavouriteserviceRepository favouriteRepository;

	@Autowired
	public FavouriteServiceImpl(FavouriteserviceRepository favouriteRepository) {
		this.favouriteRepository = favouriteRepository;
	}


	public Favourite createFavourite(Favourite favourite) throws FavouriteNotCreatedException {
		Favourite resObj = new Favourite();
		if (favourite != null) {
			resObj = favouriteRepository.insert(favourite);// Insertion
		}
		if (resObj == null || resObj.equals(null)) {
			throw new FavouriteNotCreatedException("Favourite Not Created");// If -ve case throw exception
		}
		return resObj;
	}


	public List<Favourite> getAllFavourites() {
		return favouriteRepository.findAll();
	}
}