package com.stackroute.favouriteservice.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.favouriteservice.exception.FavouriteNotCreatedException;
import com.stackroute.favouriteservice.exception.FavouriteNotFoundException;
import com.stackroute.favouriteservice.model.Favourite;
import com.stackroute.favouriteservice.service.FavouriteService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/*
 * As in this assignment, we are working with creating RESTful web service, hence annotate
 * the class with @RestController annotation.A class annotated with @Controller annotation
 * has handler methods which returns a view. However, if we use @ResponseBody annotation along
 * with @Controller annotation, it will return the data directly in a serialized 
 * format. Starting from Spring 4 and above, we can use @RestController annotation which 
 * is equivalent to using @Controller and @ResposeBody annotation
 */
@RestController
@Api
@CrossOrigin(origins = "*") // Means to that get URL access with no address specification
public class FavouriteserviceController {
	
	/*
	 * Autowiring should be implemented for the FavouriteService. (Use
	 * Constructor-based autowiring) Please note that we should not create any
	 * object using the new keyword
	 */
	FavouriteService favoriteService;

	@Autowired
	public FavouriteserviceController(FavouriteService favoriteService) {
		this.favoriteService = favoriteService;
	}

	/*
	 * Swagger
	 */
	@GetMapping("/")
	public String swaggerUi() {
		return "redirect:/swagger-ui.html";
	}

	
	@ApiOperation(value = "Create Favourite")
	@PostMapping("/api/v1/favourite")
	public ResponseEntity<Favourite> createFavourite(@RequestBody Favourite favourite) {
		favourite.setFavouriteCreationDate(new Date());
		try {
			favoriteService.createFavourite(favourite);
			return new ResponseEntity<Favourite>(favourite, HttpStatus.CREATED);// 201
		} catch (FavouriteNotCreatedException e) {
			return new ResponseEntity<Favourite>(HttpStatus.CONFLICT);// 409
		}
	}

	

	
	@ApiOperation(value = "Get All Favourite")
	@GetMapping("/api/v1/favourite/{user}")
	public ResponseEntity<List<Favourite>> getFavouriteByUser(@PathVariable("user") String user) {
		List<Favourite> favourite = favoriteService.getAllFavourites();
		List<Favourite> favByUser= new ArrayList<Favourite>();		
		if (favourite == null) {
			return new ResponseEntity<List<Favourite>>(HttpStatus.NOT_FOUND);
		}
		for(Favourite fav:favourite)
		{		
			if(fav.getFavouriteCreatedBy()!=null) {
		if (user.equalsIgnoreCase(fav.getFavouriteCreatedBy())){
			favByUser.add(fav);
		}
			}
		}
		return new ResponseEntity<List<Favourite>>(favByUser, HttpStatus.OK);
	}
}